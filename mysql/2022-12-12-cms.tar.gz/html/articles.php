<!DOCTYPE html>
<html lang="en">
<head>
<title>Articles</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="container">

<?php
     	include('header.php');
?>


<?php

include('includes/db.php');

$query=mysqli_query($conn,'select * from articles order by pub_date desc limit 10');

if (mysqli_num_rows($query) == 0) {
	echo 'No Articles found!';
} else {

?>

<h2>Articles:</h2>
<ul>
	<?php
		while ($article=mysqli_fetch_assoc($query)) {
		echo '<body>' .'<h3>'.$article['title'].'</h3>' .$article['text']. '<br>' . 'Views: ' .$article['views']. ' | ' . 'Published: ' .$article['pub_date']. '<br><br>' . '</body>';
		}
	?>
</ul>

<?php
}

$query -> free_result();
$conn->close();

        include('footer.php');
?>
</div>
</body>
</html>
