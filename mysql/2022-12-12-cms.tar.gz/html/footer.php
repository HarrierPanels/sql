<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div class="container">

<hr>
Harrier Panels &copy; <?php echo date('Y') ?>
</div>
</body>
</html>

