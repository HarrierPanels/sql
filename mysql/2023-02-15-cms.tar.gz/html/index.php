<!DOCTYPE html>
<html lang="en">
<head>
<title>CMS: Aviation Blog Template</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="container">

<?php

include('includes/db.php');

$query=mysqli_query($conn,'select * from categories');

if (mysqli_num_rows($query) == 0) {
	echo 'No categories found!';
} else {

?>

<?php
     	include('header.php');
?>

<h2>Categories:</h2>
<ul>
	<?php
		while ($category=mysqli_fetch_assoc($query)) {
		$art_count=mysqli_query($conn,'select count(id) total from articles where category_id=' . $category['id']);
		$total=mysqli_fetch_assoc($art_count);
		if ($total['total'] == 0) {
		echo '<li>' .$category['title']. ' (' .$total['total']. ')</li>';
		} else {
		echo '<li>' . '<a href=articles.php>' .$category['title']. ' (' .$total['total']. ')</a></li>';		
		}
		}
	?>
</ul>

<?php
}

$art_count -> free_result();
$query -> free_result();
$conn->close();
        
	include('footer.php');
?>
</div>
</body>
</html>
