<hr>
Harrier Panels &copy; <?php echo date(Y) ?>
