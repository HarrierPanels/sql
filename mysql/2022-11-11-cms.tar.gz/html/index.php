
<head>
<link rel=stylesheet href="css/main.css">
</head>

<?php

include('includes/db.php');

$query=mysqli_query($conn,'select * from categories');

if (mysqli_num_rows($query) == 0) {
	echo 'No categories found!';
} else {

?>

<?php
     	include('header.php');
?>

<h2>Categories:</h2>
<ul>
	<?php
		while ($category=mysqli_fetch_assoc($query)) {
		$art_count=mysqli_query($conn,'select count(id) total from articles where category_id=' . $category[id]);
		$total=mysqli_fetch_assoc($art_count);
		if ($total[total] == 0) {
		echo '<li>' .$category[title]. ' (' .$total[total]. ')</li>';
		} else {
		echo '<li>' . '<a href=articles.php>' .$category[title]. ' (' .$total[total]. ')</a></li>';		
		}
		}
	?>
</ul>

<?php
}
?>

<?php
        include('footer.php');
?>

<?php
	include('includes/db_close.php');
?>
