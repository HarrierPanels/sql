<?php

include('includes/db.php');

?>

<?php

$user=$_GET[user];
$password=$_GET[password];

$count=mysqli_query($conn,"select * from users where user='$user' and password='$password'");

if (mysqli_num_rows($count) == 0) {

	echo 'You are not registered!';

} else {

echo 'Hello ' .$user. '!';

}

?>

<?php
        include('includes/db_close.php');
?>

