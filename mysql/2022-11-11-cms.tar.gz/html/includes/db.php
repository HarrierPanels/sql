<?php

$conn=mysqli_connect('localhost', 'a', '7Ujm8ik,9ol.', 'cms_db');

if ($conn == false) {
        echo 'Failure! ';
        echo mysqli_connect_error();
        exit();
}

?>

<?php
//     	mysqli_close($conn);
?>

