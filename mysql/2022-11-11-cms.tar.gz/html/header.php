<?php

include(includes/'db.php');

?>
<title>CMS: Aviation Blog Template</title>
<a href=index.php><h1>Aviation Blog</h1></a>
<img src="images/b737.jpg">
<span style="text-align: right">
<form method=GET action='/handle.php'>
	<input type='text' placeholder='User Name' name='user'>
	<input type='text' placeholder='Password' name='password'>
	<br><br>
	<input type='submit' value='Login'>
</form>
</span>
