
<head>
<link rel=stylesheet href="css/main.css">
<title>Articles</title>
</head>

<?php
     	include('header.php');
?>


<?php

include('includes/db.php');

$query=mysqli_query($conn,'select * from articles');

if (mysqli_num_rows($query) == 0) {
	echo 'No Articles found!';
} else {

?>

<h2>Articles:</h2>
<ul>
	<?php
		while ($article=mysqli_fetch_assoc($query)) {
		$art=mysqli_query($conn,'select * total from articles where category_id=' . $article[id]);
		$total=mysqli_fetch_assoc($art);
		echo '<body>' .'<h3>'.$article[title].'</h3>' .$article[text]. '<br>' . 'Views: ' .$article[views]. '<br><br>' . '</body';
		}
	?>
</ul>

<?php
}
?>

<?php
        include('footer.php');
?>

<?php
	include('includes/db_close.php');
?>
