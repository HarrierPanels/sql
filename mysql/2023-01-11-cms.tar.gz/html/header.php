<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div class="container">

<?php

include('includes/db.php');

?>
<a href=index.php><h1>Aviation Blog</h1></a>
<img src="images/b737.jpg">
<span style="text-align: right">

     <form action="/handle.php" method="post">

        <?php if (isset($_POST['error'])) { ?>

            <p class="error"><?php echo $_POST['error']; ?></p>

        <?php } ?>

        <label>User Name</label>

        <input type="text" name="user" placeholder="User Name"><br>

        <label>Password</label>

        <input type="password" name="password" placeholder="Password"><br> 

        <button type="submit">Login</button>

     </form>

</span>
</div>
</body>
</html>
