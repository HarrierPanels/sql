<!DOCTYPE html>
<html lang="en">
<head>
<title>CMS User Panel</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<?php

include('includes/db.php');

?>

<ul>

<?php

$user=$_POST['user'];
$password=$_POST['password'];

$count=mysqli_query($conn,"select * from users where user='$user' and password='$password'");

if (!$count || mysqli_num_rows($count) == 0) {

        echo '<h3>Login failed!</h3>';
        echo '<h4 style="color:red;">Wrong User Name or Password!</h4>';

} else {

echo '<h2>Hello ' .$user. '!</h2><br /><br />';
if (!($result=mysqli_query($conn,"show tables where tables_in_cms_db <> 'users'")))
    printf("Error: %s\n", mysqli_error($conn));

echo "<h1>CMS User Panel</h1><br />";

while($row = mysqli_fetch_row( $result ))
    echo '<li><h4>' .$row[0]. '</h4></li>';

$count -> free_result();
$result -> free_result();
$conn->close();

}

?>
</ul>
</div>
</body>
</html>
